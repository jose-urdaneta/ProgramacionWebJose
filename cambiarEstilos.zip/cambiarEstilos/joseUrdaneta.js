// Prediccion 1 imprime Tengo 25 a;os
// Prediccion 2 imprime tambien Tengo 25 a;os
// Prediccion 3 imprime 1er num segundo numero y el 27 como resultado
